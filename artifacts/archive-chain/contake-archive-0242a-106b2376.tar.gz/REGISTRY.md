# Contake — REGISTRY (אינדקס ארtefacts קנוני)
עודכן: 17.9.2026 02:42 | בעלים: TL | כלל: פריט שלא כאן = לא קיים לצוות.

| פריט | sha256 | סטטוס | provenance | יעד |
|---|---|---|---|---|
| contake-content-in-context-v0.1.md | 002e177b834a89e38f692d1a025e233b0dde1b838acd0b37fcab7e7c076e059e | active | TL session 17.9 | docs/ |
| contake-contracts-v1.19-addendum-idempotency-tombstone.md | 8b2f2dbdf8fe37d6d5446f67a0324c2c9d35849d5fc6bbe0f26ab68e0d15de91 | active | TL session 17.9 | docs/ |
| contake-contracts-v1.19-i18n-dropin.md | 95c705fe2f7d4d0f103104cd1fc33efef1b78ce019934fd8c89958b0b433bb2e | active | TL session 17.9 | docs/ |
| contake-contracts-v1.20-addendum-builder-stakeholders-branches.md | 123ea918f83b72e530f560ba9c77da5caf890ab9cef8ff955066cc0e6b658189 | superseded | TL session 17.9 | docs/ |
| contake-contracts-v1.20-builder-stakeholders-branches-APPROVED.md | 9072f5a7d2c0f810d725fd860409b62deb4d34e04c601c4911d3c7f4a4a50925 | superseded | TL session 17.9 | docs/ |
| contake-contracts-v1.20.md | 1bffd2305b314d80a8c223af70745ac11d2f28e131f83f585154a9190dc7fba0 | active | TL session 17.9 | docs/ |
| contake-founder-definition-gap-audit-v1.0.md | 518bdbfe98a74b404c9b12eca2dffe158b6df0d10be27d35606c32e05f19fcff | active | TL session 17.9 | docs/ |
| contake-gate-protocol-v1.0.md | a8f739516105b0aea2c039833080cd29b883704faced15a99535dfcdfa1999be | active | TL session 17.9 | docs/ |
| contake-i18n-en-support-v0.1.md | cb702f646f6242293a1bdd52deb037d42a6f6e5f639ddb52c8c9ad2be48c8f76 | active | TL session 17.9 | docs/ |
| contake-preservation-inventory-v1.0.md | 56c1026891d06ca03f54f2bde4cd5a2df7817b01d65dec87366a4442e231641d | active | TL session 17.9 | docs/ |
| contake-preservation-protocol-v1.0.md | d30aac7da65946fcd6fddca04143afafbb05e0f4c843e62f4c51aaccea093b0f | superseded | TL, הוראת מייסד 02:40 | docs/ |
| contake-preservation-protocol-v1.1.md | f6c12aa4bedcd6ab561390fc5499df65ad9c32e943738e843135d1091dcea44e | superseded | TL, הוראת מייסד 02:40 | docs/ |
| contake-preservation-protocol-v1.2.md | d3a13b17851d50c5b0588c2e4c342b370f0313591700540827b2d7f64d6d56d7 | active | TL, הוראת מייסד 02:40 | docs/ |
| contake-quality-constitution-v1.1.md | 534c12438e6b7f8d7dd07ce1cd520975f7523d2d33713094514023d2ee673364 | active | TL, הוראת מייסד 02:40 | docs/ |
| contake-revised-critical-path-v1.0.md | f6fc10209ae546d2ecf06f78c69e89d5044f08dcd162f91f65b607f2d2bf8e84 | superseded | TL, הוראת מייסד 02:40 | docs/ |
| contake-revised-critical-path-v1.1.md | 52c0f5b82d39ba29a5bfc1f81bdaf97f6250ca9087e6550e3b9fd1b38aa977a6 | active | TL, הוראת מייסד 02:40 | docs/ |
| contake-saturday-sprint-plan-v1.0.md | d03cd47e8f2e7f0168a1daa416a813d7995d6d145aff609d17f713fdf96435c8 | active | TL, הוראת מייסד 02:40 | docs/ |
| manifest.v1.20.sha256 | 7fffd41b547b3bda49e91737dea163b8e3ed6b270bd9e2dcbc023002fd00ab75 | active | TL, הוראת מייסד 02:40 | artifacts/ |
| matrix.v1.5.additions.json | 16b4b1b01e60e83ac6f42366d049c773edf6df5ff3aa66df4d9f0d47eb80592f | active | TL, הוראת מייסד 02:40 | scripts/e2e/evidence/ |
| audit-evidence-8825a971.mjs | 3c3b4ec436c88635637765495c5636f8cfd27ef591d7152dafab2b5b453756f8 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/ |
| audit-evidence-a52190f5.mjs | 70531e8803db107dd7ddb6cf0831aca8f31ee9d1923e26f4cec1f5868cffc4b9 | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
| audit-staging-4aca7f5c.json | ee4528228fadd374a668c93b8db2f2911d849cc1622ac129cbd59d8604312ee8 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| audit-staging-b625545c.json | 1b5a9e9a20343d7e82c4e173f96b7f6b81cd5514c6cdccd7a0031708cd4572e6 | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| conc-local-27316d64.json | 35906f4f75d673b269e9db0de07276e6fe2a20b6360a885980892d3df8aa12d5 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| conc-local-ad35fe79.json | 6f18ba82e7554e617305b68b5e9f6b86125ad3e8a5bd81049bdf7e1fb5f724f5 | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| concurrency-suite-1541b9e2.mjs | d8511b1a6a8e04b2f3b8da8b92d9e4edbbbfd37f9c4f9d71dff8e6210a4564e7 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/ |
| concurrency-suite-dba54337.mjs | 86c30fbc9d5e0443938e4eb725386d9593f635d47da00a3062e50882ac3fd103 | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
| contake-data-reliability-spec-v0.1-16a7b953.md | 0ba8edc51a5efb284e3baf22383033297f924fb2c19b7d5824eb2a1ce288eaaf | active | צוותים שונים, 16-17.9 | docs/ |
| contake-fe-recovery-20260917.tar-7135cdc3.gz | dea3aae633a23925475c2a419e0712d1f5d91d5dc6208177ab2b32a15acceb52 | active | צוותים שונים, 16-17.9 | artifacts/ |
| contake-pilot-fe-prod-20260917-0031.tar-89b75f77.gz | 05df2e9fec7e98d0594a0fc180978a20ce13aa96ebdbc58350091cdb90619d4f | active | צוותים שונים, 16-17.9 | artifacts/ |
| contake-pqm2-stakeholders-branches-v1.20.tar-ca470066.gz | a1b69fa4ee62edabde280a9ca217c25d4cc0a213590db43d28c2feb3b1a3bda6 | active | צוותים שונים, 16-17.9 | artifacts/ |
| contake-twelve-minutes-final-203f1463.mp4 | 103f8a8e507812932787041471d06782043bbe0fecf732e1d805609f7f2e5f8f | active | צוותים שונים, 16-17.9 | artifacts/ |
| demo-reanchor-4e286510.mjs | 7f84ad07d26f1efb04c5305c5040888cafe06e666298e9aa8c836949c9cf6bf2 | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
| dispatch-evidence-8542600e.mjs | 00ac149cf8d8150dbef037ccbe62f9f91724b57a074d38222bbc8299891dcf7b | superseded | צוותים שונים, 16-17.9 | scripts/e2e/ |
| dispatch-evidence-b76542c3.mjs | 4ff90a54e258757bdaf118ce957e9ee062867442135f72d26b8d51c7cb12a6ab | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
| dispatch-staging-a249d75b.json | ad278add34070ffe62fe53458e686efc2d5a35dc9756cf5a94e29d026d70e26c | superseded | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| dispatch-staging-c6b0863b.json | b72cd27033c288f22b45d9a4c02d771e7433b5fde8ce9228310d83e093f5d11d | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| e2e-bilingual-skeleton-21282a20.md | 70cabcb5bb8fc89ec7031029d25288433f06c568f978c05777e704a3edc61b3e | active | צוותים שונים, 16-17.9 | docs/ |
| e2e-content-in-context-plan-87cc764f.md | 9f8d5e9ab1d5e9f25ca037f5a306cacdc61195a0507fe56892b3d02e3a1f8d35 | active | צוותים שונים, 16-17.9 | docs/ |
| e2e-resilience-coverage-f4214eb0.md | daf465556b6483e40ee39c22cd82e138a554930260fb6133534696f5cac50c15 | active | צוותים שונים, 16-17.9 | docs/ |
| e2e-staging-evidence-848f3011.json | 2f616e001937328bd7bab8313b2b936db4595a9a9c08f1f8a3008a18b84b8875 | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| field-reality-report-c2de554e.md | e913e2b6561e886c905475533f98aa311ac025c3d84b5bf6128df133649f0c5a | active | צוותים שונים, 16-17.9 | docs/ |
| idem-staging-583fb09b.json | a204a7b5eb7019f9ca398000205a94f7268ce4557d93b96baece124c99a9b7f8 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| idem-staging-a33f55fe.json | 6850a32cc0700fc84c8fe40615a6b27bf1c4a58fffe11945ebe4c8099ff7d1c6 | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| idempotency-contract-1c55692e.mjs | ba4219eef605bd5c0c8142f6aafd35af94b6c17bb0d32f532774d909db18daf0 | superseded | צוותים שונים, 16-17.9 | scripts/e2e/ |
| idempotency-contract-b386903b.mjs | 80a63a253725b3593f46e105c64c09e2396dae7ce91b69765d942699563f6da9 | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
| otp-proof-harness-evidence-f444bc6b.json | ec3ac75d3f89534611d8023168a1eca67e02500ff5ecdb4dc54b23ddf4353712 | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| reanchor-evidence-staging-0f8801c6.json | 4e97050d036ec303f81202c338192a05b075f4e14d25cb11908691d54c4eea8a | active | צוותים שונים, 16-17.9 | scripts/e2e/evidence/ |
| vertical-domino-fdac9cf8.mjs | 7c87bcbb2794bdbe3b9b62ad910222369f5b0bd920e539862aec470e3e16723d | active | צוותים שונים, 16-17.9 | scripts/e2e/ |
