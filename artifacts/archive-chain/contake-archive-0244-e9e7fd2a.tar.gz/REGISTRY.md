# Contake — REGISTRY (אינדקס ארtefacts קנוני) v1.2
עודכן: 17.9 02:44 | בעלים: TL | commit: pending archive PR | פריט שלא כאן = לא קיים.
רישום, מניפסט ו-DELETION-LOG נשלטים דרך העץ (self-registered).

| פריט | sha256(12) | נוצר | גרסה | סטטוס | קישור/נימוק | יעד |
|---|---|---|---|---|---|---|
| DELETION-LOG.md | c2738e20908e | 2026-09-17 02:43 IDT | - | active | - | docs/ |
| audit-evidence-8825a971.mjs | 3c3b4ec436c8 | 2026-09-17 02:42 IDT | - | superseded | ← a52190f5 | scripts/e2e/ |
| audit-evidence-a52190f5.mjs | 70531e8803db | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| audit-staging-4aca7f5c.json | ee4528228fad | 2026-09-17 02:42 IDT | - | superseded | ← b625545c | scripts/e2e/evidence/ |
| audit-staging-b625545c.json | 1b5a9e9a2034 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| conc-local-27316d64.json | 35906f4f75d6 | 2026-09-17 02:42 IDT | - | superseded | ← ad35fe79 | scripts/e2e/evidence/ |
| conc-local-ad35fe79.json | 6f18ba82e755 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| concurrency-suite-1541b9e2.mjs | d8511b1a6a8e | 2026-09-17 02:42 IDT | - | superseded | ← dba54337 | scripts/e2e/ |
| concurrency-suite-dba54337.mjs | 86c30fbc9d5e | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| contake-content-in-context-v0.1.md | 002e177b834a | 2026-09-17 02:42 IDT | v0 | active | - | docs/ |
| contake-contracts-v1.19-addendum-idempotency-tombstone.md | 8b2f2dbdf8fe | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-contracts-v1.19-i18n-dropin.md | 95c705fe2f7d | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-contracts-v1.20-addendum-builder-stakeholders-branches.md | 123ea918f83b | 2026-09-17 02:42 IDT | v1 | rejected | rejected: סתירות מול main, הוחלף ב-1bffd230 | docs/ |
| contake-contracts-v1.20-builder-stakeholders-branches-APPROVED.md | 9072f5a7d2c0 | 2026-09-17 02:42 IDT | v1 | rejected | rejected: אושר טרם reconciliation, הוחלף ב-1bffd230 | docs/ |
| contake-contracts-v1.20.md | 1bffd2305b31 | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-data-reliability-spec-v0.1-16a7b953.md | 0ba8edc51a5e | 2026-09-17 02:42 IDT | v0 | active | - | docs/ |
| contake-design-preservation-team-b-2026-09-17.tar-4c87a686.gz | fe11e50973ac | 2026-09-17 02:43 IDT | - | archive | Team B research/Taste Bible, 35 פריטים (fe11e509) | artifacts/ |
| contake-design-preservation-team-b-2026-09-17.tar.gz-9c7cfda2.sha256 | 2d89e000f8a1 | 2026-09-17 02:43 IDT | - | archive | sidecar של חבילת Team B | artifacts/ |
| contake-fe-recovery-20260917.tar-7135cdc3.gz | dea3aae633a2 | 2026-09-17 02:42 IDT | - | archive | PARTIAL ≠ RC 1789434469015 — ראיית שחזור (infra dea3aae6) | artifacts/ |
| contake-founder-definition-gap-audit-v1.0.md | 518bdbfe98a7 | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-gate-protocol-v1.0.md | a8f739516105 | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-i18n-en-support-v0.1.md | cb702f646f62 | 2026-09-17 02:42 IDT | v0 | active | - | docs/ |
| contake-pilot-fe-prod-20260917-0031.tar-89b75f77.gz | 05df2e9fec7e | 2026-09-17 02:42 IDT | - | archive | בסיס-השוואה RC (ממתין לאישור infra) | artifacts/ |
| contake-pqm2-stakeholders-branches-v1.20.tar-ca470066.gz | a1b69fa4ee62 | 2026-09-17 02:42 IDT | v1 | archive | ממתין ל-loader קנוני | artifacts/ |
| contake-preservation-infra-release-20260917.tar-3ed5221a.gz | ff90e59b4377 | 2026-09-17 02:42 IDT | - | archive | חבילת infra/release, 11 פריטים (ff90e59b) | artifacts/ |
| contake-preservation-inventory-v1.0.md | 56c1026891d0 | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-preservation-migration-20260917T0241-IDT.tar-ed8adf2a.gz | 084397e2b534 | 2026-09-17 02:43 IDT | - | archive | חבילת מיגרציה quality/design, 33 פריטים (084397e2) | artifacts/ |
| contake-preservation-protocol-v1.0.md | d30aac7da659 | 2026-09-17 02:42 IDT | v1 | superseded | ← v1.2 | docs/ |
| contake-preservation-protocol-v1.1.md | f6c12aa4bedc | 2026-09-17 02:42 IDT | v1 | superseded | ← v1.2 | docs/ |
| contake-preservation-protocol-v1.2.md | d954aa4a72ec | 2026-09-17 02:43 IDT | v1 | active | - | docs/ |
| contake-quality-constitution-v1.1.md | 534c12438e6b | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-revised-critical-path-v1.0.md | f6fc10209ae5 | 2026-09-17 02:42 IDT | v1 | superseded | ← v1.1 | docs/ |
| contake-revised-critical-path-v1.1.md | 52c0f5b82d39 | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-saturday-sprint-plan-v1.0.md | d03cd47e8f2e | 2026-09-17 02:42 IDT | v1 | active | - | docs/ |
| contake-twelve-minutes-final-203f1463.mp4 | 103f8a8e5078 | 2026-09-17 02:42 IDT | - | archive | סרטון דמו | artifacts/ |
| demo-reanchor-4e286510.mjs | 7f84ad07d26f | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| dispatch-evidence-8542600e.mjs | 00ac149cf8d8 | 2026-09-17 02:42 IDT | - | superseded | ← b76542c3 | scripts/e2e/ |
| dispatch-evidence-b76542c3.mjs | 4ff90a54e258 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| dispatch-staging-a249d75b.json | ad278add3407 | 2026-09-17 02:42 IDT | - | superseded | ← c6b0863b | scripts/e2e/evidence/ |
| dispatch-staging-c6b0863b.json | b72cd27033c2 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| e2e-bilingual-skeleton-21282a20.md | 70cabcb5bb8f | 2026-09-17 02:42 IDT | - | active | - | docs/ |
| e2e-content-in-context-plan-87cc764f.md | 9f8d5e9ab1d5 | 2026-09-17 02:42 IDT | - | active | - | docs/ |
| e2e-resilience-coverage-f4214eb0.md | daf465556b64 | 2026-09-17 02:42 IDT | - | active | - | docs/ |
| e2e-staging-evidence-848f3011.json | 2f616e001937 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| field-reality-report-c2de554e.md | e913e2b6561e | 2026-09-17 02:42 IDT | - | active | - | docs/ |
| idem-staging-583fb09b.json | a204a7b5eb70 | 2026-09-17 02:42 IDT | - | superseded | ← a33f55fe | scripts/e2e/evidence/ |
| idem-staging-a33f55fe.json | 6850a32cc070 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| idempotency-contract-1c55692e.mjs | ba4219eef605 | 2026-09-17 02:42 IDT | - | superseded | ← b386903b | scripts/e2e/ |
| idempotency-contract-b386903b.mjs | 80a63a253725 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| manifest.v1.20.sha256 | 7fffd41b547b | 2026-09-17 02:42 IDT | v1 | active | - | artifacts/ |
| matrix.v1.5.additions.json | 16b4b1b01e60 | 2026-09-17 02:42 IDT | v1 | active | - | artifacts/ |
| otp-proof-harness-evidence-f444bc6b.json | ec3ac75d3f89 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| reanchor-evidence-staging-0f8801c6.json | 4e97050d036e | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/evidence/ |
| vertical-domino-fdac9cf8.mjs | 7c87bcbb2794 | 2026-09-17 02:42 IDT | - | active | - | scripts/e2e/ |
| REGISTRY.md | (self) | 17.9 02:44 | v1.2 | active | ← v1.1 | docs/ |
| ARCHIVE-MANIFEST.sha256 | (self) | 17.9 02:44 | - | active | ← b1838ead bundle (superseded) | docs/ |
| DELETION-LOG.md | (self) | 17.9 02:44 | - | active | - | docs/ |
| contake-archive-20260917-0242.tar.gz | b1838eadf6db | 17.9 02:42 | - | superseded | ← 03678028; הושמט ממנו רישום infra/pkg — פגם שתוקן | artifacts/ |
| contake-archive-20260917-0243.tar.gz | 03678028d772 | 17.9 02:43 | - | superseded | ← current; חסרו שתי חבילות העיצוב ברישום | artifacts/ |
